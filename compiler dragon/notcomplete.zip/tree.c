#include <stdlib.h>
#include <stdio.h>
#include <assert.h>
#include <string.h>
#include "node.h"
#include "tree.h"
#include "y.tab.h"

/* contructor */
tree_t *make_tree(int type, tree_t *left, tree_t *right){

	tree_t *p=(tree_t *)malloc(sizeof(tree_t));
	assert(p != NULL);

	p->type=type;
	p->left=left;
	p->right=right;

	return p;
}

tree_t *make_op(int type, int attribute, tree_t *left, tree_t *right){

	tree_t *p=make_tree(type,left,right);
	p->attribute.opval=attribute;
	return p;
}

tree_t *make_inum(int val){

	tree_t *p=make_tree(INUM,NULL,NULL);
	p->attribute.ival=val;
	return p;
}

tree_t *make_rnum(float val){

	tree_t *p=make_tree(RNUM,NULL,NULL);
	p->attribute.rval=val;
	return p;
}

tree_t *make_id(node_t *node){

	tree_t *p=make_tree(ID,NULL,NULL);
	p->attribute.sval=node;
	return p;
}

tree_t *make_array(){
	
}
tree_t *make_arr();
tree_t *make_subdecl();
tree_t *make_subdecls();
tree_t *make_decl();
tree_t *make_cond();
tree_t *make_whdo():
tree_t *make_optstat();
tree_t *make_stm();
tree_t *make_procedure();
tree_t *make_function();


/* preorder */
void print_tree(tree_t *t, int spaces){

	int i;

	if(t == NULL){
		return;
	}

	for(i=0;i<spaces;i++){
		fprintf(stderr, " ");
	}

	/* process root */
	switch(t->type){
		case ID:
			fprintf(stderr, "[ID:%s\n",(t->attribute.sval)->name);
			break;
		case INUM:
			fprintf(stderr, "[INUM:%d\n",t->attribute.ival);
			break;
		case RNUM:
			fprintf(stderr, "[RNUM:%f\n",t->attribute.rval);
			break;
		case ADDOP:
			print_ADDOP(t->type);
			break;
		case MULOP: 
			print_MULOP(t->type);
			break;
		case RELOP: 
			print_RELOP(t->type);
			break;
		default:
			fprintf(stderr, "[UNKOWN]");
	}
	//fprintf(stderr, "\n");
	/* go left */
	print_tree(t->left,spaces+4);
	/*go right */
	print_tree(t->right,spaces+4);

}

void print_ADDOP(int opval){
	swtich(opval){
		case OR:
			fprintf(stderr, "[ADDOP: or\n");
			break;
		case PLUS:
			fprintf(stderr, "[ADDOP: +\n");
			break;
		case MINUS:
			fprintf(stderr, "[ADDOP: -\n");
			break;
		default:
			fprintf(stderr, "[UNKOWN]");
	}
}

void print_MULOP(int opval){
	switch(opval){
		case AND:
			fprintf(stderr, "[MULLOP: and\n");
			break;
		case STAR:
			fprintf(stderr, "[MULLOP: *\n");
			break;
		case SLASH:
			fprintf(stderr, "[MULLOP: /\n");
			break;
		case DIV:
			fprintf(stderr, "[MULLOP: div\n");
			break;
		case MOD:
			fprintf(stderr, "[MULLOP: mod\n");
			break;
		default:
			fprintf(stderr, "[UNKOWN]");
	}
}

void print_RELOP(int opval){
	switch(opval){
		case LT:
			fprintf(stderr, "[RELOP: <\n");
			break;
		case LE:
			fprintf(stderr, "[RELOP: <=\n");
			break;
		case GT:
			fprintf(stderr, "[RELOP: >\n");
			break;
		case GE:
			fprintf(stderr, "[RELOP: =>\n");
			break;
		case EQ:
			fprintf(stderr, "[RELOP: =\n");
			break;
		case NEQ:
			fprintf(stderr, "[RELOP: <>\n");
			break;
		default:
			fprintf(stderr, "[UNKOWN]");
	}
}


